/* $Id: patchlevel.h,v 1.1 2004/12/13 22:05:15 keil Exp $ */

#define VERSION		"2.4.3"
#define DATE		"13 November 2004"
