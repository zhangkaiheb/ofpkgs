void dsp_timer_service(unsigned long dummy)
{
	MODEM_PTR pmodem;
	u16 monitor_state;
	u16 link_state;
	u16 current_state = ADSL_IDLE;
	u32 flags=0;
	pmodem = gmodem;
    	if (pmodem != NULL)
    	{	    
		monitor_state = adsl_monitor(pmodem);
		link_state = adsl_link_state(pmodem);
		if ((monitor_state == 0) && (link_state == 2))
			current_state = ADSL_SYNC;
		if ((monitor_state == 0) && (link_state == 1))
			current_state = ADSL_TRAINING;
		if (current_state != last_state)
		{
			if ((current_state == ADSL_IDLE) && (last_state == ADSL_SYNC))
			{
				adsl_led_off(pmodem, LINK_LED);
				printk(KERN_ERR PTAG"Link Down\n"); 
				retrain(pmodem);
			};
			if (current_state == ADSL_SYNC)
			{
				adsl_led_on(pmodem, LINK_LED);
				printk(KERN_ERR PTAG"Link Up\n");
				retrain_timer = 0;
			};	
			last_state = current_state;
		}
		if (current_state != ADSL_SYNC)
		{	
			retrain_timer++;
			adsl_led_toggle(pmodem, LINK_LED);
			if (retrain_timer > 30) //retrain after 1 min
				retrain(pmodem);
		};
		//spin_unlock_irqrestore(rx_lock, flags);
		if (current_state == ADSL_SYNC)
		{
		    if (tx_running == FALSE)
			tx_cells(pmodem);
		    else // check for a dma timeout
		    {
			if (tx_dma_count > 10) //timeout
			{
				//spin_lock_irqsave(tx_lock, flags);
				spin_lock(&tx_lock);
				tx_dma_count = 0;
				tx_running = FALSE;
				//spin_unlock_irqrestore(tx_lock, flags);
				spin_unlock(&tx_lock);
				tx_cells(pmodem);
				printk("Tx DMA timeout\n");
				printk("last_start = %lx last_end = %lx\n",last_start,last_end);
			}	
			else
				tx_dma_count++;
//			if (tx_dma_count == 1)
//				printk("Count = 1 ");	
			if (tx_dma_count == 2)
				printk("Count = 2 ");	
			if (tx_dma_count == 5)
				printk("Count = 5 ");	
		    }
		}	

		//spin_unlock_irqrestore(tx_lock, flags);
	}
	spin_lock(&timer_lock);
    	if (dsp_timer_stop == FALSE) 
    	{	    
        	dsp_timer.expires = jiffies + DSP_TIMER_RELOAD;
        	add_timer(&dsp_timer);	
    	};	
	spin_unlock(&timer_lock);
}

