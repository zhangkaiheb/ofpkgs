/* $Id: patchlevel.h,v 1.1 2003/05/18 20:22:12 calle Exp $ */

#define VERSION		"2.4.2b3"
#define DATE		"1 May 2003"
