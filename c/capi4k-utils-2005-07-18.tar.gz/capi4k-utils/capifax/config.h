/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader 2.13.  */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

#define VERSION "1.0"
#define PACKAGE "capifax"
/* #undef CONFIG_SBINDIR */
/* #undef CONFIG_MANDIR */

/* Define if you have the <sys/ioctl.h> header file.  */
#define HAVE_SYS_IOCTL_H 1

/* Define if you have the <unistd.h> header file.  */
#define HAVE_UNISTD_H 1

/* Name of package */
#define PACKAGE "capifax"

/* Version number of package */
#define VERSION "1.0"

/* we have SENDING_COMPLETE in ALERT_REQ */
#define HAVE_ALERT_SENDING_COMPLETE 1

/* we have GLOBALCONFIGURATION in BProtocol */
#define HAVE_GLOBALCONFIGURATION 1

