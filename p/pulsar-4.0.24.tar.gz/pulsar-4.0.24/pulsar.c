// Pulsar PCI ADSL Linux Driver - ATM API
//
// Authors - Guy Ellis (guy@traverse.com.au)
//           Nathan Williams (nathan@traverse.com.au)
//
// History Summary - for details see release notes
// V4.0.24 - Now also supports Sangoma S518-C ADSL card
//         - Driver status now available through /proc/driver/pulsar/pulsarX (e.g. pulsar0, pulsar1, ... )
//         - Library update to 4.0.12
//         - Fixed bug with spinlock
// v4.0.23 - Support for OA&M F4 and F5 ATM cell loopback
// v4.0.22 - Library update to 4.0.11
//         - Link speed, SNR & Attenuation now logged when sync is achieved
// v4.0.21-pre2 - spinlocks changed to irq save, removed malloc from ISR
// v4.0.21-pre1 - support for more than 1 card added
// v4.0.19 - Library update to 4.0.8 ++
// v4.0.18 - DMA Restart after sync loss fixed
// v4.0.17 - Added 2.6 changes from Alan Swanson 
// v4.0.16 - Support for 2.4 and 2.6 Kernels
//
// Acknowledgements
// Thanks to...
// Alan Swanson - 2.6 support and debugging
// Johan Verrept - SAR Library
// Wayne Peart - Our Globespan FAE
// Charles Michael Heard - CRC-10 routine


#include <linux/version.h> 

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0))
	#define MODULE
#else
	#include <linux/interrupt.h>
#endif

#include <linux/module.h>
#include <linux/kernel.h> /* printk() */
#include <linux/errno.h>  /* error codes */
#include <linux/ioport.h>  
#include <asm/io.h>
#include <linux/timer.h>
#include <linux/pci.h>
#include <linux/skbuff.h>
#include <linux/atm.h>
#include <linux/atmdev.h>
#include <linux/proc_fs.h>
#include "pulsar.h"
#include "sarlib.h"

#define MAX_TX_DMA (1 + SARLIB_DEF_MTU_AAL5 / 48) * 53

#define VERSION "V4.0.24"

#undef CELL_LOOP
//#define CELL_LOOP
#undef SAR_LOOP
//#define SAR_LOOP

#undef DEBUG
//#define DEBUG 1

#ifdef DEBUG
#define PDEBUG(arg...)  printk(KERN_ALERT "pulsar: " arg)
#else
#define PDEBUG(arg...)
#endif


// Globals todo - clean these up - move to pmodem structure
static char name[16];
static struct timer_list dsp_timer;
static u16 last_state = 0xFFFF; 
static int dsp_timer_stop;
static int dev_number = 0;
static void *txb;

MODULE_AUTHOR("Traverse Technologies <support@traverse.com.au>");
MODULE_DESCRIPTION("Pulsar PCI ADSL driver");
MODULE_LICENSE("GPL");
MODULE_PARM_DESC(dev_number, "PCI Device Number");

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,17))
module_param(dev_number, int, 0);
#else
MODULE_PARM(dev_number, "b");
#endif

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0))
	struct tq_struct rx_bh_task;
#else
	struct tasklet_struct rx_bh_task;
#endif

static unsigned char *oam_cell = NULL;

static int retrain_timer;
spinlock_t oam_lock = SPIN_LOCK_UNLOCKED;
spinlock_t rx_lock = SPIN_LOCK_UNLOCKED;
spinlock_t timer_lock = SPIN_LOCK_UNLOCKED;
static spinlock_t tx_lock = SPIN_LOCK_UNLOCKED;
CBUF_STRUCT rx_cbuf[RX_CBUF_SIZE];
int rx_head=0, rx_tail=0;
static int tx_dma_count = 0;
static u32 last_start=0;
static u32 last_end=0;
static int tx_running = FALSE;
static int rx_pdu_cnt = 0;

static sarlib_vcc_data_t *sarlib_vcc_list = NULL; // list of sarlib vccs in use

static struct atm_dev *atmdev; // ATM device pointer

struct atm_vcc *init_vcc(short vpi, int vci);
static MODEM_PTR global_pmodem = NULL;
static struct proc_dir_entry *pulsar_dir = NULL;
static struct proc_dir_entry *pulsar_proc = NULL;

//***************************************************************
// CRC-10 table generated using code from:
// http://cell.onecall.net/cell-relay/publications/software/CRC/crc10.html
//
// Charles Michael Heard
//
//***************************************************************

static unsigned short byte_crc10_table[256] = {
	0x000, 0x233, 0x255, 0x066, 0x299, 0x0aa, 0x0cc, 0x2ff, 
	0x301, 0x132, 0x154, 0x367, 0x198, 0x3ab, 0x3cd, 0x1fe, 
	0x031, 0x202, 0x264, 0x057, 0x2a8, 0x09b, 0x0fd, 0x2ce, 
	0x330, 0x103, 0x165, 0x356, 0x1a9, 0x39a, 0x3fc, 0x1cf, 
	0x062, 0x251, 0x237, 0x004, 0x2fb, 0x0c8, 0x0ae, 0x29d, 
	0x363, 0x150, 0x136, 0x305, 0x1fa, 0x3c9, 0x3af, 0x19c, 
	0x053, 0x260, 0x206, 0x035, 0x2ca, 0x0f9, 0x09f, 0x2ac, 
	0x352, 0x161, 0x107, 0x334, 0x1cb, 0x3f8, 0x39e, 0x1ad, 
	0x0c4, 0x2f7, 0x291, 0x0a2, 0x25d, 0x06e, 0x008, 0x23b, 
	0x3c5, 0x1f6, 0x190, 0x3a3, 0x15c, 0x36f, 0x309, 0x13a, 
	0x0f5, 0x2c6, 0x2a0, 0x093, 0x26c, 0x05f, 0x039, 0x20a, 
	0x3f4, 0x1c7, 0x1a1, 0x392, 0x16d, 0x35e, 0x338, 0x10b, 
	0x0a6, 0x295, 0x2f3, 0x0c0, 0x23f, 0x00c, 0x06a, 0x259, 
	0x3a7, 0x194, 0x1f2, 0x3c1, 0x13e, 0x30d, 0x36b, 0x158, 
	0x097, 0x2a4, 0x2c2, 0x0f1, 0x20e, 0x03d, 0x05b, 0x268, 
	0x396, 0x1a5, 0x1c3, 0x3f0, 0x10f, 0x33c, 0x35a, 0x169, 
	0x188, 0x3bb, 0x3dd, 0x1ee, 0x311, 0x122, 0x144, 0x377, 
	0x289, 0x0ba, 0x0dc, 0x2ef, 0x010, 0x223, 0x245, 0x076, 
	0x1b9, 0x38a, 0x3ec, 0x1df, 0x320, 0x113, 0x175, 0x346, 
	0x2b8, 0x08b, 0x0ed, 0x2de, 0x021, 0x212, 0x274, 0x047, 
	0x1ea, 0x3d9, 0x3bf, 0x18c, 0x373, 0x140, 0x126, 0x315, 
	0x2eb, 0x0d8, 0x0be, 0x28d, 0x072, 0x241, 0x227, 0x014, 
	0x1db, 0x3e8, 0x38e, 0x1bd, 0x342, 0x171, 0x117, 0x324, 
	0x2da, 0x0e9, 0x08f, 0x2bc, 0x043, 0x270, 0x216, 0x025, 
	0x14c, 0x37f, 0x319, 0x12a, 0x3d5, 0x1e6, 0x180, 0x3b3, 
	0x24d, 0x07e, 0x018, 0x22b, 0x0d4, 0x2e7, 0x281, 0x0b2, 
	0x17d, 0x34e, 0x328, 0x11b, 0x3e4, 0x1d7, 0x1b1, 0x382, 
	0x27c, 0x04f, 0x029, 0x21a, 0x0e5, 0x2d6, 0x2b0, 0x083, 
	0x12e, 0x31d, 0x37b, 0x148, 0x3b7, 0x184, 0x1e2, 0x3d1, 
	0x22f, 0x01c, 0x07a, 0x249, 0x0b6, 0x285, 0x2e3, 0x0d0, 
	0x11f, 0x32c, 0x34a, 0x179, 0x386, 0x1b5, 0x1d3, 0x3e0, 
	0x21e, 0x02d, 0x04b, 0x278, 0x087, 0x2b4, 0x2d2, 0x0e1};


//***************************************************************
//// Retrain Routine
////***************************************************************
void retrain(MODEM_PTR pmodem)
{
	retrain_timer=0;
	adsl_train(pmodem);
}

//***************************************************************
// Interrupt Service Routine
//***************************************************************

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,19))
irqreturn_t isr(int irq, void *dev_id)
{
        MODEM_PTR pmodem = (MODEM_PTR)dev_id;

        if (adsl_irq_pending(pmodem))
        {
                adsl_irq_service(pmodem);
                return IRQ_HANDLED;
        }
        return IRQ_NONE;
}
#elif (LINUX_VERSION_CODE >= KERNEL_VERSION(2,5,0))
irqreturn_t isr(int irq, void *dev_id, struct pt_regs *regs)
{
        MODEM_PTR pmodem = (MODEM_PTR)dev_id;

        if (adsl_irq_pending(pmodem))
        {
                adsl_irq_service(pmodem);
                return IRQ_HANDLED;
        }
	return IRQ_NONE;
}
#else
void isr(int irq, void *dev_id, struct pt_regs *regs)
{
	MODEM_PTR pmodem = (MODEM_PTR)dev_id;

	if (adsl_irq_pending(pmodem))
		adsl_irq_service(pmodem);
}
#endif


//***************************************************************
// Timer Routines
// todo : add tx dma timeout
//***************************************************************

void dsp_timer_service(unsigned long data)
{
	MODEM_PTR pmodem = (MODEM_PTR)data;
	unsigned long flags;
	u16 monitor_state;
	u16 link_state;
	u16 current_state = ADSL_IDLE;
	int snr;
	unsigned int atten;

    	if (pmodem != NULL)
    	{	    
		monitor_state = adsl_monitor(pmodem);
		link_state = adsl_link_state(pmodem);
		if ((monitor_state == 0) && (link_state == 2))
			current_state = ADSL_SYNC;
		if ((monitor_state == 0) && (link_state == 1))
			current_state = ADSL_TRAINING;
		if (current_state != last_state)
		{
			if ((current_state == ADSL_IDLE) && (last_state == ADSL_SYNC))
			{
				adsl_led_off(pmodem, LINK_LED);
				printk(KERN_NOTICE "%s: Link Down\n", name); 
				retrain(pmodem);
			};
			if (current_state == ADSL_SYNC)
			{
				adsl_led_on(pmodem, LINK_LED);
				adsl_get_status(pmodem); // get line speed etc
				snr = pmodem->snr_margin * 5;
				atten = pmodem->line_atten * 5;
				printk(KERN_NOTICE "%s: Link Up\n", name);
				printk(KERN_INFO "%s: Speed %d/%d SNR Margin %d.%ddB Line Atten %d.%ddB\n", name, pmodem->us_rate, pmodem->ds_rate, snr/10, snr%10, atten/10, atten%10);
				retrain_timer = 0;
			};	
			last_state = current_state;
		}
		if (current_state != ADSL_SYNC)
		{	
			retrain_timer++;
			adsl_led_toggle(pmodem, LINK_LED);
			if (retrain_timer > 30) //retrain after 1 min
				retrain(pmodem);
		};
		if (current_state == ADSL_SYNC)
		{
		    if (tx_running == FALSE)
			tx_cells(pmodem);
		    else // check for a dma timeout
		    {
			if (tx_dma_count > 10) //timeout
			{
				spin_lock_irqsave(&tx_lock, flags);
				tx_dma_count = 0;
				tx_running = FALSE;
				spin_unlock_irqrestore(&tx_lock, flags);
				tx_cells(pmodem);
				printk(KERN_ERR "%s: Tx DMA timeout\n", name);
				printk(KERN_DEBUG "%s: last_start = %x last_end = %x\n",
					name, last_start, last_end);
			}	
			else
				tx_dma_count++;
		    }
		}	
	}
	spin_lock_irqsave(&timer_lock, flags);
    	if (dsp_timer_stop == FALSE) 
    	{	    
        	dsp_timer.expires = jiffies + DSP_TIMER_RELOAD;
        	add_timer(&dsp_timer);	
    	};	
	spin_unlock_irqrestore(&timer_lock, flags);
}

//***************************************************************
// ATM vcc init - for testing only
// normally this is done by the kernel
//***************************************************************

struct atm_vcc *init_vcc(short vpi, int vci)
{
	struct atm_vcc *new;
	struct sock *new_sock;
	new = kmalloc (sizeof (struct atm_vcc), GFP_KERNEL);
	if (!new)
	        return NULL;
	memset( new, 0, sizeof (struct atm_vcc));
	
	//new->flags = SARLIB_SET_PTI;		/* VCC flags (ATM_VF_*) */

	new->vpi = vpi;		/* VPI and VCI (types must be equal */
					/* with sockaddr) */
	new->vci = vci;
	//struct sock	*sk;		/* socket backpointer */
	new_sock = kmalloc (sizeof (struct sock), GFP_KERNEL);
	if (!new_sock)
	        return NULL;
	memset( new_sock, 0, sizeof (struct sock));
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,12))
	new = atm_sk(new_sock);
#else
	new->sk = new_sock;	
#endif
	return(new);		  
}	

//***************************************************************
// TX Routines
//***************************************************************
void tx_cells(MODEM_PTR pmodem)
{
	unsigned long flags;
	u32 cell_ptr, size;
	u32 tx_start, tx_end;
	struct sk_buff *skb;
#ifdef DEBUG
	int i;
#endif	
	spin_lock_irqsave(&tx_lock, flags);
	if ((tx_running == FALSE) && (oam_cell != NULL)){
//#ifdef DEBUG
//	  for (i=0;i<(ATM_CELL_SIZE-1);i++){
//		PDEBUG("%X ",(unsigned int)oam_cell[i]);
//	  }
//#endif
	  PDEBUG("oam_cell at address: %X\n", (unsigned int)oam_cell);
		
	  size = ATM_CELL_SIZE-1; //52 bytes
	  if (size > MAX_TX_DMA)
          {
            size = MAX_TX_DMA;
            printk(KERN_WARNING "%s: Tx DMA truncated\n", name);
          }
#ifdef DEBUG
	  PDEBUG("oam_cell at address: %x\n", (unsigned int)oam_cell);
#endif	 
	  spin_lock(&oam_lock); 
	  memcpy(txb, oam_cell, size);
          kfree(oam_cell); 
	  oam_cell = NULL;
	  spin_unlock(&oam_lock);
#ifdef DEBUG
	  PDEBUG("oam_cell at address: %X\n", (unsigned int)oam_cell);
#endif
          // todo check for left overs
          cell_ptr = (u32)txb;
          tx_dma_count = 0;
          tx_start = (u32)virt_to_bus((void *)cell_ptr);
          tx_end = tx_start + size;
          tx_running = TRUE;
          last_start = tx_start;
          last_end = tx_end;
          adsl_tx(pmodem, tx_start, tx_end);
          spin_unlock_irqrestore(&tx_lock, flags); 
	}
	else if ((tx_running == FALSE) && (sarlib_vcc_list))// there is no dma pending
	{
		// try and get someting from the tx_queue
		// todo check all vccs
		skb = skb_dequeue(&sarlib_vcc_list->tx_queue);
		// if there is something to send get a dma buffer
		if (skb) // there is 
		{
			sarlib_vcc_list->tx_queue_size--;
			size = skb->len;
			if (size > MAX_TX_DMA)
			{
				size = MAX_TX_DMA;
				printk(KERN_WARNING "%s: Tx DMA truncated\n", name);
			}
			memcpy(txb, (void *)skb->data, size);
			dev_kfree_skb(skb);
			// todo check for left overs
			cell_ptr = (u32)txb;
			tx_dma_count = 0;
			tx_start = (u32)virt_to_bus((void *)cell_ptr);
			tx_end = tx_start + size;
			tx_running = TRUE;
			last_start = tx_start;
			last_end = tx_end;
			adsl_tx(pmodem, tx_start, tx_end);
			spin_unlock_irqrestore(&tx_lock, flags);
		}
		else
			spin_unlock_irqrestore(&tx_lock, flags);
	}
	else
		spin_unlock_irqrestore(&tx_lock, flags);
}


void tx_done(MODEM_PTR pmodem)
{
	unsigned long flags;
	
	spin_lock_irqsave(&tx_lock, flags);
	tx_running = FALSE;
	spin_unlock_irqrestore(&tx_lock, flags);
	tx_cells(pmodem);
}

int add_tx_list(MODEM_PTR pmodem, struct sarlib_vcc_data *ctx, struct sk_buff *skb)
// skb version 
{
	unsigned long flags;
	
	spin_lock_irqsave(&tx_lock, flags);
	skb_queue_tail(&ctx->tx_queue,skb);
	ctx->tx_queue_size++;
	spin_unlock_irqrestore(&tx_lock, flags);
	if (tx_running == FALSE)
		tx_cells(pmodem);
	return(1); // ok
}	
	

int tx_process(MODEM_PTR pmodem, struct sarlib_vcc_data *ctx,struct sk_buff *skb)
{
	struct sk_buff *myskb, *skbo1, *skbo2;
	int size;
	int result=0;
	

	//printk("tx_process()\n");
	size = skb->len;
        if (!(myskb = dev_alloc_skb(size)))
	{	
		printk(KERN_WARNING "%s: Failed to allocate sk_buff in tx_process()\n", name);
		return(result);
	}
//printk("dev_alloc_skb in tx_process() @ %x, size = %d\n",myskb,size);
	memcpy(skb_put(myskb, size), (void *)skb->data, size);
	myskb->len=size;
	skbo1 = sarlib_encode_aal5(ctx, myskb);
	//printk("skb = %x myskb = %x skbo1 = %x\n",skb,myskb,skbo1);
	if (skbo1)
	{
		if (skbo1 != myskb)
			dev_kfree_skb(myskb);
		skbo2 = sarlib_encode_rawcell(ctx, skbo1);
		if (skbo2)
		{	
			if (skbo2 != skbo1)
				dev_kfree_skb(skbo1);
			result=add_tx_list(pmodem, ctx, skbo2);
			//if (!result) //tx queue is full
			//	dev_kfree_skb(skbo2);
		}
		else		
			printk(KERN_WARNING "%s: Null ptr returned by salib_encode_rawcell()\n", name);
	}
	else
		printk(KERN_WARNING "%s: Null ptr returned by salib_encode_aal5()\n", name);
	return(result);
}



//***************************************************************
// CRC-10 routine from:
// http://cell.onecall.net/cell-relay/publications/software/CRC/crc10.html
//
// Charles Michael Heard
//
//***************************************************************

unsigned short update_crc10_by_bytes(unsigned short crc10_accum, unsigned char *data_blk_ptr, int data_blk_size){
/* update the data block's CRC-10 remainder one byte at a time */

	register int i;
	for ( i = 0; i < data_blk_size; i++ )
	{
		crc10_accum = ((crc10_accum << 8) & 0x3ff)
			^ byte_crc10_table[( crc10_accum >> 2) & 0xff]
			^ *data_blk_ptr++;
	}
	return crc10_accum;
}
 
//***************************************************************
// RX Routines
//***************************************************************

void rx_process_cells(MODEM_PTR pmodem, struct sk_buff *skb, u16 size)
{
// call decode_raw_cell for each cell	
// if end of aal5 call decode_aal5
// then pass on to protocol layer 
	u16	pos = 0;
	struct sk_buff *skb1,*skb2;
	struct sarlib_vcc_data *ctx;
	unsigned char *cell = skb->data;
	unsigned long atmHeader;
	unsigned int vpi, vci, pti;
	unsigned short int crc10_accum = 0;
#ifdef DEBUG
	int j = 0;
#endif

#ifdef DEBUG
	PDEBUG("START of WHILE\n"); 
#endif
	while((cell - skb->data) < size){
#ifdef DEBUG
		j++;
#endif
	  atmHeader = ((unsigned long)(cell[0]) << 24) | ((unsigned long)(cell[1]) << 16) | ((unsigned long)(cell[2]) << 8) | (cell[3] & 0xff);
	  vpi = (unsigned int)((atmHeader & ATM_HDR_VPI_MASK) >> ATM_HDR_VPI_SHIFT);
	  vci = (unsigned int)((atmHeader & ATM_HDR_VCI_MASK) >> ATM_HDR_VCI_SHIFT);
	  pti = (unsigned int)((atmHeader & ATM_HDR_PTI_MASK) >> ATM_HDR_PTI_SHIFT);
	  if ((pti == 5) || (pti == 4) || (vci == 3) || (vci == 4)){
	    spin_lock(&oam_lock); 
	    if (oam_cell == NULL){
	      oam_cell = kmalloc((ATM_CELL_SIZE-1), GFP_KERNEL); //allocate 52 bytes
	      if(oam_cell != NULL){
	        memcpy(oam_cell,cell,(ATM_CELL_SIZE-1));
		oam_cell[5]=0; //set loopback indication
		oam_cell[50]=0;
		oam_cell[51]=0;
		crc10_accum = update_crc10_by_bytes(0,(oam_cell+4)  , 48);
		oam_cell[50]= (crc10_accum >> 8);
		oam_cell[51]= (crc10_accum & 0x00ff);
#ifdef DEBUG
	        PDEBUG("Allocated OAM cell space\n");
#endif
	      } else {
#ifdef DEBUG
	        PDEBUG("Kmalloc Failed!\n");
#endif
	      }

	    }
	    else {
#ifdef DEBUG
	      PDEBUG("oam_cell not NULL!\n");
	      PDEBUG("Skipped memcpy\n");
#endif	      
	    }
#ifdef DEBUG
	    PDEBUG("OAM VPI:%d VCI:%d PTI:%d\n", vpi,vci,pti);
#endif
	    spin_unlock(&oam_lock);

	  } else {
//	  printk(KERN_DEBUG "non-oam %d %d %d\n", vpi,vci,pti);

	  }
          cell = cell + (ATM_CELL_SIZE - 1);  //add 52 bytes
	}  
#ifdef DEBUG
	PDEBUG("%d cells\n",j); 
	PDEBUG("END of WHILE\n"); 
#endif	
	if(sarlib_vcc_list)
	{
	    while (pos < size)
	    {	    
		skb1 = sarlib_decode_rawcell(sarlib_vcc_list, skb, &ctx);
		pos += ATM_CELL_SIZE;
		skb2=NULL;
		if (skb1) // end of aal5
		{	
			skb2 = sarlib_decode_aal5(ctx, skb1);
			if (skb1 != skb2)
				dev_kfree_skb(skb1);
		};
		if (skb2) // got a pdu
		{
			rx_pdu_cnt++;	
//		       	printk("RX PDU count = %d\n",rx_pdu_cnt);
			//printk("rx_process()\n");	
			if ((ctx) && (ctx->vcc) && (ctx->vcc->push))
			{
				ctx->vcc->push(ctx->vcc,skb2);
			}
		}
	    }	
	}	
}	
	
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0))
void rx_bh_service(void *data)
#else
void rx_bh_service(unsigned long data)
#endif
{
	MODEM_PTR pmodem = (MODEM_PTR)data;
	u32 cell_ptr; 
	u32 size;
	u16 num_cells;
	int rhead, rtail;
        struct sk_buff *skb;

	spin_lock_bh(&rx_lock);
	rhead = rx_head;
	rtail = rx_tail;
	// check rx buffer, there should be cells
	while (rhead != rtail)
	{	
		cell_ptr = rx_cbuf[rtail].cell_ptr;
		num_cells = rx_cbuf[rtail].num_cells;
		
		rtail++;
		if(rtail >= RX_CBUF_SIZE)
			rtail = 0;
		rx_tail = rtail;		
		size = sizeof(ATM_CELL) * num_cells;
		
		
	        if (!(skb = dev_alloc_skb(size)))
			printk(KERN_ERR "%s: Failed to allocate sk_buff in rx_bh_service()\n", name);
	        else 
		{
	               	memcpy(skb_put(skb, size), (void *)cell_ptr, size);
			// loopback / sar now
#ifdef CELL_LOOP
			add_tx_list(pmodem, skb);
#else
			rx_process_cells(pmodem, skb, size);
//printk("dev_kfree_skb in rx_bh_service() @ %x\n",skb);
			dev_kfree_skb(skb);
#endif
		}		
		
	}
	spin_unlock_bh(&rx_lock);
}	

//***************************************************************
// Kernel ATM Callbacks
//***************************************************************

//void dev_close(struct atm_dev *dev)
//optional TBD
//{
//}	

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0))
int popen(struct atm_vcc *vcc,short vpi,int vci)
{
	//MODEM_PTR pmodem = (MODEM_PTR)vcc->dev->dev_data; // XXX: For printk name

	printk(KERN_INFO "%s: Open for vpi %d and vci %d \n", name, vpi, vci);
	//printk("Pulsar_open: VCC->VPI is %d \n", vcc->vpi);
	//printk("Pulsar_open: VCC->VCI is %d \n", vcc->vci);
	//printk("Pulsar_open: VCC address is %08x \n", vcc);
	//printk("Pulsar_open: push address is %08x \n", vcc->push);
	//printk("Pulsar_open: pop  address is %08x \n", vcc->pop);
	vcc->vpi = vpi;
	vcc->vci = vci;
	set_bit(ATM_VF_ADDR, &vcc->flags); // accept the vpi / vci
	set_bit(ATM_VF_READY, &vcc->flags); // we are ready to go -> hook to line sync later
	// add to our sarlib_vcc_list - todo spinlock this
	// also todo add to last int list
	sarlib_vcc_list = sarlib_open(&sarlib_vcc_list, vcc, SARLIB_TYPE_AAL5, vpi, vci, 0, 0, SARLIB_SET_PTI) ;
	skb_queue_head_init(&sarlib_vcc_list->tx_queue);
	sarlib_vcc_list->tx_queue_size = 0;
	MOD_INC_USE_COUNT;
	return(0);
}	
#else
int popen(struct atm_vcc *vcc)
{
	//MODEM_PTR pmodem = (MODEM_PTR)vcc->dev->dev_data; // XXX: For printk name

	printk(KERN_INFO "%s: Open for vpi %d and vci %d \n", name, vcc->vpi, vcc->vci);
	//printk("Pulsar_open: VCC->VPI is %d \n", vcc->vpi);
	//printk("Pulsar_open: VCC->VCI is %d \n", vcc->vci);
	//printk("Pulsar_open: VCC address is %08x \n", vcc);
	//printk("Pulsar_open: push address is %08x \n", vcc->push);
	//printk("Pulsar_open: pop  address is %08x \n", vcc->pop);
	set_bit(ATM_VF_ADDR, &vcc->flags); // accept the vpi / vci
	set_bit(ATM_VF_READY, &vcc->flags); // we are ready to go -> hook to line sync later
	// add to our sarlib_vcc_list - todo spinlock this
	// also todo add to last int list
	sarlib_vcc_list = sarlib_open(&sarlib_vcc_list, vcc, SARLIB_TYPE_AAL5, vcc->vpi, vcc->vci, 0, 0, SARLIB_SET_PTI) ;
	skb_queue_head_init(&sarlib_vcc_list->tx_queue);
	sarlib_vcc_list->tx_queue_size = 0;
	return(0);
}	
#endif

void pclose(struct atm_vcc *vcc)
//optional TBD2
//call sarlib
{
	//MODEM_PTR pmodem = (MODEM_PTR)vcc->dev->dev_data; // XXX: For printk name
	sarlib_vcc_data_t *vcc_list_ptr;
	u8 found=0;

	printk(KERN_INFO "%s: Close for vpi %d and vci %d ", name, vcc->vpi, vcc->vci);
	clear_bit(ATM_VF_ADDR, &vcc->flags); 
	clear_bit(ATM_VF_READY, &vcc->flags); 
	
	vcc_list_ptr = sarlib_vcc_list; // start at the head
	while ((vcc_list_ptr) && (found==0))
	{
		if ((vcc->vpi == vcc_list_ptr->vp) &&
			(vcc->vci == vcc_list_ptr->vc)) // we have a match
		{
			found=1;
		}	
		else
			vcc_list_ptr = vcc_list_ptr->next; // try the next one
	}
	if (found)
	{	
		vcc_list_ptr->vcc = NULL;
		printk("(closed)\n");
	} else {
		printk("(not found)\n");
	}
	//sarlib_close(&sarlib_vcc_list, vcc);
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0))
	MOD_DEC_USE_COUNT;
#endif
}	

int pioctl(struct atm_dev *dev,unsigned int cmd,void *arg)
{
	printk(KERN_DEBUG "%s: ATM ioctl called\n", PTAG);
	return(0);
}

int pgetsockopt(struct atm_vcc *vcc,int level,int optname,void *optval,int optlen)
{
	printk(KERN_DEBUG "%s: ATM getsockopt called\n", PTAG);
	return(0);
}	

int psetsockopt(struct atm_vcc *vcc,int level,int optname,void *optval,int optlen)
{
	printk(KERN_DEBUG "%s: ATM setsockopt called\n", PTAG);
	return(0);
}	

int psend(struct atm_vcc *vcc,struct sk_buff *skb)
//mandatory TBD1
{
	MODEM_PTR pmodem = (MODEM_PTR)vcc->dev->dev_data;
	sarlib_vcc_data_t *vcc_list_ptr;
	u8 found=0;
	int result=0;

	//printk("psend() \n");
	// use the vpi / vci to find the matching ctx in sarlib_vcc_list
	vcc_list_ptr = sarlib_vcc_list; // start at the head
	while ((vcc_list_ptr) && (found==0))
	{
		if ((vcc->vpi == vcc_list_ptr->vp) &&
			(vcc->vci == vcc_list_ptr->vc)) // we have a match
		{
			found=1;
			//printk("Found a match in send\n");
		}	
		else
			vcc_list_ptr = vcc_list_ptr->next; // try the next one
	}
	if (found)
		result = tx_process(pmodem, vcc_list_ptr, skb);
	else
		printk(KERN_NOTICE "%s: vcc not found in psend()\n", name);
	// now pop it
	if (vcc->pop == NULL)
	{	
		printk(KERN_NOTICE "%s: Can't pop....\n", name);
		dev_kfree_skb(skb);
	}
	else
	{
		//printk(KERN_DEBUG "Popping....\n", name);
		vcc->pop(vcc,skb);
	}
	if (result)
		return(0);
	else 
		return(-EAGAIN);
//	if (found)
//		return(0);
//	else
//		return(1);
}	

#define SKIP
#ifndef SKIP
int psg_send(struct atm_vcc *vcc,unsigned long start,unsigned long size)
//optional TBD TBD3
{
}	

int pchange_qos(struct atm_vcc *vcc,struct atm_qos *qos,int flags)
//optional LATER
{
}	

/* @@@ temporary hack */

int pproc_read(struct atm_dev *dev,loff_t *pos,char *page)
//don't know
{
}	
#endif

//***************************************************************
// Proc Routines
//***************************************************************

int pulsar_read_procmem(char *buf, char **start, off_t offset, 
		int count, int *eof, void *data){
  int len = 0;
  u16 monitor_state;
  u16 link_state;
  int current_state = 1;
  int snr = 0;
  int us_rate = 0;
  int ds_rate = 0;
  unsigned int atten = 0;

  if(offset > 0 ) {
    *eof = 1;
    return 0;
  }

  if (global_pmodem != NULL)
        {
          monitor_state = adsl_monitor(global_pmodem);
          link_state = adsl_link_state(global_pmodem);
            us_rate = global_pmodem->us_rate;
            ds_rate = global_pmodem->ds_rate;
	    snr = global_pmodem->snr_margin * 5;
            atten = global_pmodem->line_atten * 5;
          if ((monitor_state == 0) && (link_state == 2) && (us_rate >= 0) && (ds_rate >= 0) && (snr >= 0) && (atten >= 0)){
            current_state = 0; //ADSL_SYNC
	    snr = global_pmodem->snr_margin * 5;
            atten = global_pmodem->line_atten * 5;
            us_rate = global_pmodem->us_rate;
            ds_rate = global_pmodem->ds_rate;
          } else {
	    us_rate =0;
	    ds_rate =0;
	    snr =0;
	    atten =0;
	    current_state = 1;
	  }
  }
  len = sprintf(buf,"%s %d %d %d %d.%d %d.%d\n", VERSION, current_state, us_rate, ds_rate, snr/10, snr%10, atten/10, atten%10);
  *eof = 1;
  return len;
}





//***************************************************************
// Initialisation Routines
//***************************************************************

void start_training(MODEM_PTR pmodem)
//ref gppci.c gsi_start_train()
{
	unsigned long flags;
	u16 modulation, trellis;
	
	modulation = GDMT;
	//modulation = MULTIMODE;
	trellis = TRELLIS_ON;
	// initialise modem
	adsl_config(pmodem,modulation,trellis);
	retrain(pmodem);
	
	adsl_led_on(pmodem, PWR_LED);
	// start the DSP timer
	spin_lock_irqsave(&timer_lock, flags);
	dsp_timer.expires = jiffies + DSP_TIMER_RELOAD;
	add_timer(&dsp_timer);
	spin_unlock_irqrestore(&timer_lock, flags);
}

static CB_STRUCT cbs = {
	.hw_read =		&hw_read,
	.hw_readb =		&hw_readb,
	.hw_write =		&hw_write,
	.hw_writeb =		&hw_writeb,
	.cb_delay =		&cb_delay,
	.allocate_spin_lock =	&allocate_spin_lock,
	.free_spin_lock =	&free_spin_lock,
	.acquire_spin_lock =	&acquire_spin_lock,
	.release_spin_lock =	&release_spin_lock,
	.adsl_rx_cells =	&adsl_rx_cells,
	.adsl_tx_done =		&adsl_tx_done
};

static struct atmdev_ops pulsar_ops = {
	.open =		popen,
	.close =	pclose,
	.ioctl =	pioctl,
	.getsockopt =	pgetsockopt,
	.setsockopt =	psetsockopt,
	.send =		psend,
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0))
	.sg_send =	NULL,
	.feedback =	NULL,
#endif
	.send_oam =	NULL,
	.phy_put =	NULL,
	.phy_get =	NULL,
	.change_qos =	NULL,
	.proc_read =	NULL,
	.owner =	THIS_MODULE
};

static int pulsar_init_one(struct pci_dev *pci_dev, const struct pci_device_id *ent)
{
	MODEM_PTR pmodem = NULL;
	static int index = 0;
	u32 modem_size;
	int err;

	unsigned long membase = pci_resource_start(pci_dev, 0);
	unsigned long memlen = pci_resource_len(pci_dev, 0);

	char proc_name[24]; //Later set to "driver/pulsar/pulsarX" where X is dev_number

	index = dev_number;	// XXX: To be removed for new PCI style

	/* Initialise modem resources */
	pmodem = (MODEM_PTR)kmalloc(sizeof(MODEM_PTR), GFP_KERNEL);
	global_pmodem = pmodem;
	if (!pmodem) {
		printk(KERN_ERR "%s%d: Unable to allocate memory for modem\n", PTAG, index);
		err = -ENOMEM;
		goto pulsar_init_exit;
	}
	
	memset(pmodem, 0, sizeof(MODEM_PTR));
	PDEBUG("oam_cell points to %p\n", oam_cell);

	sprintf(name, "%s%d", PTAG, index);

	modem_size = adsl_sizeof();
	pmodem->handle = (void *)kmalloc(modem_size, GFP_KERNEL);
	if (!pmodem->handle) {
		printk(KERN_ERR "%s: Unable to allocate memory for handle\n", name);
		err = -ENOMEM;
		goto pulsar_init_exit_free;
	}
	memset(pmodem->handle, 0, modem_size);

	txb = (void *)kmalloc(MAX_TX_DMA, __GFP_DMA);
	if (!txb) {
		printk(KERN_ERR "%s: Unable to allocate Tx DMA buffer\n", name);
		err = -ENOMEM;
		goto pulsar_init_exit_free;
	}
	
	//pmodem->rx_lock = SPIN_LOCK_UNLOCKED;
	//pmodem->tx_lock = SPIN_LOCK_UNLOCKED;
	//pmodem->timer_lock = SPIN_LOCK_UNLOCKED;
	//pmodem->tx_running = FALSE;
	//pmodem->last_state = 0xFFFF;

	//pmodem->pci_dev = pci_dev;
	pci_set_drvdata(pci_dev, pmodem);

	/* Reserve PCI I/O and memory resources */
	err = pci_enable_device(pci_dev);
	if (err) {
		printk(KERN_ERR "%s: Unable to enable PCI device\n", name);
		goto pulsar_init_exit_free;
	}
	pci_set_master(pci_dev);


//The code between here and next comment may be overwriting the end of the pmodem structure.	
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,20))
	err = pci_request_region(pci_dev, 0, name);
#else
	if (!request_mem_region(pci_resource_start(dev, 0), pci_resource_len(dev, 0), name))
		err = -EBUSY;
#endif
	if (err) {
		printk(KERN_ERR "%s: Unable to reserve PCI region\n", name);
		goto pulsar_init_exit_pci;
	}

//Somehow elements in pmodem structure can be overwritten with PCI address
	
	
	pmodem->pci_base = ioremap(membase, memlen);
	if (!pmodem->pci_base) {
		printk(KERN_ERR "%s: Unable to map PCI memory\n", name);
		err = -EIO;
		goto pulsar_init_exit_iomap;
	}

	/* Register callbacks for binary library */
	adsl_cb_init(pmodem, &cbs);

	/* Register interrupt */
	adsl_irq_disable(pmodem);
	err = request_irq(pci_dev->irq, isr, SA_SHIRQ, name, pmodem);
	if (err) {
		printk(KERN_ERR "%s: IRQ request failure\n", name);
		goto pulsar_init_exit_irq;
	}
	pmodem->irq = pci_dev->irq;

	printk(KERN_INFO "%s: Dev:0x%p IRQ:%d Address:0x%08lX Length:%ld\n",
			name, pci_dev, pci_dev->irq, membase, memlen);
	
	/* Register ATM device */
	atmdev = atm_dev_register(name, &pulsar_ops, -1, NULL);
	if (!atmdev) {
		printk(KERN_ERR "%s: Could not register ATM device\n", name);
		err = -ENODEV;
		goto pulsar_init_exit_atm;
        }
	printk(KERN_INFO "%s: Registered as ATM device %d\n",
			name, atmdev->number);
	if (!atmdev->ops)
		printk(KERN_WARNING "%s: No ATM device ops\n", name);

	atmdev->ci_range.vpi_bits = 8;
	atmdev->ci_range.vci_bits = 16;
	atmdev->dev_data = pmodem;

	/* Initialise modem */
	err = adsl_init(pmodem);
        if (err != PASS) {
		printk(KERN_ERR "%s: Failed to initialise modem in adsl_init (%d)\n", name, err);
		err = -ENODEV;
		goto pulsar_init_exit_all;
	}

	/* Initialise DSP timer */
	init_timer(&dsp_timer);
	dsp_timer.function = dsp_timer_service;
	dsp_timer.data = (unsigned long)pmodem;
	dsp_timer_stop = FALSE;

	/* Initialise Rx bottom half/tasklet */
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,5,0))
	tasklet_init(&rx_bh_task, rx_bh_service, (unsigned long)pmodem);
#else
	rx_bh_task.routine = rx_bh_service;
	rx_bh_task.data = (void *)pmodem;
#endif

	/* Allocate Rx DMA buffer */
	pmodem->rx_dma_startv = pci_alloc_consistent(pci_dev, RX_DMA_SIZE, &pmodem->rx_dma_startp);
	//printk("<1> DMA v = %x DMA p = %x \n",(u32)pmodem->rx_dma_startv, (u32)pmodem->rx_dma_startp);
	if (pmodem->rx_dma_startv == NULL) {
		printk(KERN_ERR "%s: Unable to allocate Rx DMA buffer\n", name);
		err = -ENOMEM;
		goto pulsar_init_exit_all;	
	}

	//vcc = init_vcc(8,35);
	// init sarlib, vpi/vci = 8/35 for the moment
	//sarlib_vcc_list = sarlib_open(&sarlib_vcc_list, vcc, SARLIB_TYPE_AAL5, 8, 35, 0, 0, SARLIB_SET_PTI) ;
	
	//if (sarlib_vcc_list == NULL) {
	//	printk(KERN_ERR "%s: sarlib_open failed\n", name);
	//	goto pulsar_init_exit_all;	
	//}

	pmodem->rx_dma_end = (u32)pmodem->rx_dma_startv + RX_DMA_SIZE;
	adsl_rxdma_init(pmodem, RX_DMA_SIZE);

	/* Initialise DMA timer */	// XXX: Todo

	/* Initialise LED timer */	// XXX: Todo

	/* Get MAC address */		// XXX: Todo

	/* Start training modem */

	/* Create /proc/pulsar/pulsarX */
	sprintf(proc_name, "driver/pulsar/pulsar%d", dev_number);
	pulsar_proc = create_proc_read_entry(proc_name, 0, NULL,pulsar_read_procmem,NULL);
	if (pulsar_proc == NULL){ //failed to create proc file, therefore directory /proc/driver/pulsar doesn't exist
	  pulsar_dir = proc_mkdir("driver/pulsar", NULL); //create the missing directory
	  pulsar_proc = create_proc_read_entry(proc_name, 0, NULL,pulsar_read_procmem,NULL); //try to create file again
	}
	if ((pulsar_proc == NULL) && (pulsar_dir != NULL)){
	  remove_proc_entry("driver/pulsar",NULL); //still failed, so give up and remove directory.
	}

	start_training(pmodem);
	err = 0;
	goto pulsar_init_exit;

pulsar_init_exit_all:
	atm_dev_deregister(atmdev);
pulsar_init_exit_atm:
	adsl_irq_disable(pmodem);
	free_irq(pci_dev->irq, pmodem);
pulsar_init_exit_irq:
	iounmap(pmodem->pci_base);
pulsar_init_exit_iomap:
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,20))
	pci_release_region(pci_dev, 0);
#else
	release_mem_region(membase, memlen);
#endif
pulsar_init_exit_pci:
	pci_disable_device(pci_dev);
pulsar_init_exit_free:
	pci_set_drvdata(pci_dev, NULL);
	kfree(txb);
	kfree(oam_cell); 
	kfree(pmodem->handle);
	kfree(pmodem);
pulsar_init_exit:
	index++;
	return err;
}

static void __exit pulsar_remove_one(struct pci_dev *pci_dev)
{
	MODEM_PTR pmodem = pci_get_drvdata(pci_dev);
	unsigned long flags;
	char proc_name[24]; //Later set to "driver/pulsar/pulsarX"

	adsl_shutdown(pmodem);

	adsl_led_off(pmodem, PWR_LED);
	adsl_led_off(pmodem, LINK_LED);
	adsl_led_off(pmodem, RX_LED);
	adsl_led_off(pmodem, TX_LED);

	/* Stop timers */
	spin_lock_irqsave(&timer_lock, flags);
    	dsp_timer_stop = TRUE;
    	del_timer_sync(&dsp_timer);
	spin_unlock_irqrestore(&timer_lock, flags);

	/* Stop the bh */	// XXX: Todo? Task queue for linux 2.4?
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,5,0))
	tasklet_kill(&rx_bh_task);
#endif

	atm_dev_deregister(atmdev);

	adsl_irq_disable(pmodem);
	free_irq(pci_dev->irq, pmodem);

	pci_free_consistent(pci_dev, RX_DMA_SIZE, pmodem->rx_dma_startv, pmodem->rx_dma_startp);
	iounmap(pmodem->pci_base);
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,20))
	pci_release_region(pci_dev, 0);
#else
	release_mem_region(pci_resource_start(pci_dev, 0), pci_resource_len(pci_dev, 0));
#endif
	pci_disable_device(pci_dev);

	//sarlib_close(vcc_list);
	
	/* Remove /proc/driver/pulsar/pulsarX */
	if (pulsar_proc != NULL){  //first check if we successfully made the /proc/driver/pulsar/pulsarX file
	  pulsar_dir = pulsar_proc->parent; //get the parent directory (/proc/driver/pulsar)
	  sprintf(proc_name, "driver/pulsar/pulsar%d", dev_number);
	  remove_proc_entry(proc_name,NULL); //remove /proc/driver/pulsar/pulsarX
	  if (pulsar_dir != NULL){  //sanity check
	    if (pulsar_dir->subdir == NULL){ //check whether the directory is empty
	      remove_proc_entry("driver/pulsar",NULL);//if so, remove the directory
	    }
	  }
	}
	PDEBUG("May Crash Here\n");
	kfree(txb);
	kfree(oam_cell); 
	PDEBUG("Freed oam_cell\n");
	PDEBUG("oam_cell = %p\n",oam_cell);
	
	kfree(pmodem->handle);
	kfree(pmodem);
	
}	

#ifdef PULSAR_NEWPCISTYLE
static struct pci_device_id pulsar_pci_tbl[] __devinitdata = {
	{ VID, DID, PCI_ANY_ID, PCI_ANY_ID, 0, 0, 0 },
	{ 0, }
};
MODULE_DEVICE_TABLE(pci,pulsar_pci_tbl);

static struct pci_driver pulsar_driver = {
	.name =		PTAG,
	.id_table =	pulsar_pci_tbl,
	.probe =	pulsar_init_one,
	.remove =	__devexit_p(pulsar_remove_one),
};
#endif

static int __init pulsar_init(void)
{
#ifdef PULSAR_NEWPCISTYLE
	printk(KERN_INFO "%s: PCI ADSL ATM Driver %s Lib %s loaded\n", PTAG, VERSION, getlibver());

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,5,0)
	return pci_register_driver(&pulsar_driver);
#else
	return pci_module_init(&pulsar_driver);
#endif
#else
	struct pci_dev *pci_dev = NULL;
	int dev_found = 0;

	printk(KERN_INFO "%s: PCI ADSL ATM Driver %s Lib %s loaded\n", PTAG, VERSION, getlibver());

	while ((pci_dev = pci_find_device(VID, DID, pci_dev)) != NULL) {
		if (dev_found == dev_number) // we've found the one were looking for
        		break;
	        dev_found++;
	}

	printk(KERN_DEBUG "%s: dev_found = %d, dev_number = %d\n", PTAG, dev_found, dev_number);

	if ((pci_dev) && (dev_found == dev_number)) {
		return pulsar_init_one(pci_dev, NULL);
	} else {
		printk(KERN_ERR "%s: No PCI card found\n", PTAG);
		return -ENODEV;
	}
#endif
}

static void __exit pulsar_exit(void)
{
#ifdef PULSAR_NEWPCISTYLE
	pci_unregister_driver(&pulsar_driver);
#else
	struct pci_dev *pci_dev = NULL;

	pci_dev = pci_find_device(VID, DID, pci_dev); // just one device at the moment
	pulsar_remove_one(pci_dev);
#endif
	printk(KERN_INFO "%s: PCI ADSL ATM Driver %s Lib %s unloaded\n", PTAG, VERSION, getlibver());
}

module_init(pulsar_init);
module_exit(pulsar_exit);
