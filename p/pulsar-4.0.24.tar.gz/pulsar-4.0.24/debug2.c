#include <linux/kernel.h>
#include <linux/errno.h>

void dump_cells(int tx, u32 cellptr, u16 size)
// prints out cell header contents for all cells
{
	u8 *bp;
	u16 x,y;

	bp = (u8 *)cellptr;
	y = 0;
	for (x=0;x<size;x++)
	{
	        if (y == 0)// print error level
		{	
			if (tx)
				printk("TX = ");
			else
				printk("RX = ");
		}
		if (y < 4)
		{	
			if (*bp < 0x10)
				printk("0");
			printk("%x ",*bp);
		}	
		if (y == 3) // print a newline
			printk("\n");
		bp++;
		y++;
		if (y >= 52) // end of cell
		{
			y = 0;
		};	
	};

}	

void show_cells(int tx, u32 cellptr, u16 size)
// prints out entire for each non idle cell 
{
	u8 *bp,last_byte;
	u16 x,y,z,cellcnt,idle;

	bp = (u8 *)cellptr;
	y = 0;
	z = 0;
	last_byte = 0;
	cellcnt = 0;
	idle = 1;
	for (x=0;x<size;x++)
	{
		if ((y == 1) && (*bp == 0x80))// check if cell is idle
		{	
			idle = 0; // not idle
			if (tx)
				printk("TX = ");
			else
				printk("RX = ");
			if (last_byte < 0x10)
				printk("0");
			printk("%x ",last_byte);
		};	
		if ((idle == 0) && (y < 20))
		{	
			if (*bp < 0x10)
				printk("0");
			printk("%x ",*bp);
		};
		last_byte = *bp;
		bp++;
		y++;
		if (y >= 52) // end of cell
		{
			y = 0;
			z++;
			if (idle == 0)
				printk("\n");
			idle = 1;
		};	
	};
}

u16 count_cells(u32 cellptr, u16 size)
// prints out ** for each non idle cell and counts them 
{
	u8 *bp;
	u16 x,y,z,cellcnt;

	bp = (u8 *)cellptr;
	y = 0;
	z = 0;
	cellcnt = 0;
	//printk("<1>C : ");
	for (x=0;x<size;x++)
	{
		if ((y == 1) && (*bp == 0x80))// check if cell is idle
		{	
			//printk("** ");
			cellcnt++;
		};
		bp++;
		y++;
		if (y >= 52) // end of cell
		{
			y = 0;
			z++;
		};	
	};
	return(cellcnt);
}
