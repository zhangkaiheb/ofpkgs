#ifndef DBJSON_H
#define DBJSON_H

void showjson(int dbcount);
void jsondate(time_t *date, int type);
void jsonheader(void);
void jsonfooter(void);

#endif
