// Pulsar PCI ADSL Linux Driver - dsplib callbacks
// Version 4
//
// 
// 

#include <linux/version.h>
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0))
        #define MODULE
#endif

#include <linux/module.h>
#include <linux/kernel.h> /* printk() */
#include <linux/errno.h>  /* error codes */
#include <linux/pci.h>  
#include <linux/types.h>
#include <asm/system.h>
#include <asm/io.h>
#include <linux/delay.h>
#include <linux/timer.h>
#include <linux/interrupt.h>
#include "pulsar.h"

// Globals todo
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0))
	#include <linux/tqueue.h>
        extern struct tq_struct rx_bh_task;
#else
        extern struct tasklet_struct rx_bh_task;
#endif

extern spinlock_t rx_lock;
extern CBUF_STRUCT rx_cbuf[RX_CBUF_SIZE];
extern int rx_head, rx_tail;
extern CBUF_STRUCT tx_cbuf[TX_CBUF_SIZE];
extern u16 tot_cells;		// XXX: Binary library?

typedef struct _SPIN_LOCK
{
	spinlock_t slock;
	unsigned long flags;
} SPIN_LOCK, *PSPIN_LOCK;


u32 P_REGPARM hw_read(void *pci_base, u16 Address, u8 *pData)
{
if (pci_base)
{
	u32 temp, addr;	
	udelay(1); // 1uS	
	addr = Address; 
	addr = (u32)pci_base + (addr << 2);
	temp = readl((void *)addr); // byte address used here
	rmb();
	*pData = (u8) temp;
	return(temp);
}
else
{
	printk(KERN_ERR "%s: ERROR - Null base address in hw_read()\n", PTAG);
	return(0);
}	
}

u8 P_REGPARM hw_readb(void *pci_base, u16 Address, u8 *pData)
{
if (pci_base)
{
	u8 temp;
	u32 addr;	
	udelay(1); // 1uS
	addr = Address;	
	addr = (u32)pci_base + (addr << 2);
	temp = readb((void *)addr);
	rmb();
	*pData = temp;
	return(temp);
}
else
{
	printk(KERN_ERR "%s: ERROR - Null base address in hw_readb()\n", PTAG);
	return(0);
}	
}

void P_REGPARM hw_write(void *pci_base, u16 Address, u32 Data)
{
if (pci_base)
{	
	u32 addr;	
	udelay(1); // 1uS	
	addr = Address; 
	addr = (u32)pci_base + (addr << 2);
	writel(Data, (void *)addr); // byte address used here
	wmb();
}
else
	printk(KERN_ERR "%s: ERROR - Null base address in hw_write()\n", PTAG);
}

void P_REGPARM hw_writeb(void *pci_base, u16 Address, u8 Data)
{
if (pci_base)
{	
	u32 addr;	
	udelay(1); // 1uS	
	addr = Address;	
	addr = (u32)pci_base + (addr << 2);
	writeb(Data, (void *)addr);
	wmb();
}
else
	printk(KERN_ERR "%s: ERROR - Null base address in hw_writeb()\n", PTAG);
}

void P_REGPARM cb_delay(u32 delay)
{
	udelay(delay);
}


u32 P_REGPARM allocate_spin_lock(void **plock)
{
	SPIN_LOCK *spinner;
	spinner = (SPIN_LOCK *)kmalloc(sizeof(SPIN_LOCK), GFP_KERNEL);
	spin_lock_init(&spinner->slock);
	*plock = (void *)spinner;
	return(0);
	
}

u32 P_REGPARM free_spin_lock(void *plock)
{
	kfree(plock);
	return(0);
}

u32 P_REGPARM acquire_spin_lock(void *plock)
{

	SPIN_LOCK *spinner;
	spinner = (SPIN_LOCK *)plock;
	spin_lock_irqsave(&spinner->slock, spinner->flags);
	return(0);
}

u32 P_REGPARM release_spin_lock(void *plock)
{
	SPIN_LOCK *spinner;
	spinner = (SPIN_LOCK *)plock;
	spin_unlock_irqrestore(&spinner->slock, spinner->flags);
	return(0);
}

void P_REGPARM adsl_tx_done(void *user_pmodem)
{
	MODEM_PTR pmodem;
	
	//printk("<1> Pulsar : adsl_tx_done()\n");
	pmodem = (MODEM_PTR)user_pmodem;
	tx_done(pmodem);
}

void P_REGPARM adsl_rx_cells(void *user_pmodem, u32 CellPtr, u16 ncells)
{
	MODEM_PTR pmodem;
	unsigned long flags;
	int head, tail;
	u16 size;
        
	//printk(KERN_ALERT "%s: adsl_rx_cells()\n", PTAG);
	pmodem = (MODEM_PTR)user_pmodem;
	spin_lock_irqsave(&rx_lock, flags);
	head = rx_head;
	tail = rx_tail;
	rx_cbuf[head].cell_ptr = CellPtr;
	rx_cbuf[head].num_cells = ncells;
	head++;
	size = ncells * sizeof(ATM_CELL);
//	printk(KERN_ALERT "%s: callback CellPtr = %x Cells = %x End = %x \n",PTAG,CellPtr,ncells,temp);
	//count_cells(CellPtr,size); // scan cell headers
	//printk(KERN_ALERT "%s: adsl_rx_cells : CellPtr = %x Cells = %d(dec) Tot Cells = %d(dec)\n",PTAG,CellPtr,ncells,tot_cells);
		
	if (head >= RX_CBUF_SIZE)
		head = 0;
	if (head == tail) // we have overflowed
	{		
		printk(KERN_ALERT "%s: ADSL Rx overflow\n", PTAG);	// XXX: Use pmodem name
		tail++; // scrap the oldest data
		if (tail >= RX_CBUF_SIZE)
			tail = 0;
	}	
	rx_head = head;
	rx_tail = tail;
	spin_unlock_irqrestore(&rx_lock, flags);
	// schedule bh / tasklet	
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0))
	queue_task(&rx_bh_task, &tq_immediate);
	mark_bh(IMMEDIATE_BH);
#else
	tasklet_schedule(&rx_bh_task);
#endif
	
}
