#if defined(__linux__)
#include <linux/types.h>
#include <linux/version.h>
#elif defined(__FreeBSD__)
#include <sys/types.h>
#define u32             uint32_t
#define u16             uint16_t
#define u8              uint8_t
#define dma_addr_t      vm_paddr_t
#else
#error "Unknown target OS"
#endif

#define PTAG			"pulsar"

// Disable regparm in function calls to and from the binary library
#ifndef P_REGPARM
#define P_REGPARM __attribute__((regparm(0)))
#endif

#define DSP_TIMER_RELOAD	2 * HZ // 2000ms

#define DSP_TIMER		2000  
#define PASS			1
#define FAIL			0
#define TRUE			1
#define FALSE			0
#define MAX_MODEMS		1
#define ATM_PAYLOAD_SIZE	48
#define ATM_HEADER_SIZE		4
#define VID 			0x14BC // Vendor ID
#define DID 			0xD002 // Device ID

#define LINK_LED 		0x0008
#define PWR_LED 		0x0001
#define TX_LED 			0x0004
#define RX_LED 			0x0002
#define TX_LED_RELOAD 		5 
#define RX_LED_RELOAD 		5 

#define GDMT			2
#define	MULTIMODE		4	
#define TRELLIS_ON		0x8000
#define RX_DMA_SIZE 		0x6800
//#define RX_DMA_SIZE 		33280 // 52 bytes x 40 dma cells/tfer x 16 tfers	

#define ADSL_IDLE		0
#define ADSL_TRAINING		1	
#define ADSL_SYNC		2

#define RX_CBUF_SIZE		64	
#define TX_CBUF_SIZE		64	

typedef struct _CBUF_STRUCT
{
	u32	cell_ptr;
	u16	num_cells;
} CBUF_STRUCT;

typedef struct _MODEM_STRUCT
{
	/* --- Begin binary library compat --- */
	void			*handle;
	void			*pci_base;
	int			irq;
	void			*rx_dma_startv;
	u32			rx_dma_end;
	dma_addr_t		rx_dma_startp;
	u32			us_rate;
	u32			ds_rate;
	u32			link_state;
	u8			line_atten;
	char			snr_margin;
//	unsigned char 		*oam_cell;
//	void			*rx_lock;
//	CBUF_STRUCT		rx_cbuf[RX_CBUF_SIZE];
//	int			rx_head, rx_tail;
//	void			*tx_lock;
//	CBUF_STRUCT		tx_cbuf[TX_CBUF_SIZE];
//	int			tx_head, tx_tail;
	/* --- End binary library compat ----- */

	/* --- Device ------------------------ */
//	char 			name[16];
//	struct pci_dev		*pci_dev;
//	struct atm_dev		*atm_dev;
//	sarlib_vcc_data_t	*sarlib_vcc_list;

	/* --- Spin locks -------------------- */
//	spinlock_t 		rx_lock;
//	spinlock_t		tx_lock;
//	spinlock_t		timer_lock;

	/* --- Interrupt --------------------- */
//#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,5,0))
//	struct tasklet_struct	rx_bh_task;
//#else
//	struct tq_struct	rx_bh_task;
//#endif

	/* --- Rx ---------------------------- */
//	CBUF_STRUCT		rx_cbuf[RX_CBUF_SIZE];
//	int			rx_head;
//	int			rx_tail;
//	int			rx_pdu_cnt;

	/* --- Tx ---------------------------- */
//	CBUF_STRUCT		tx_cbuf[TX_CBUF_SIZE];
//	void			*txb;
//	int			tx_running;
//	int			tx_dma_count;
//	u32			last_start;
//	u32			last_end;

	/* --- Timer ------------------------- */
//	struct timer_list	dsp_timer;
//	u16			last_state;
//	int			dsp_timer_stop;
//	int			retrain_timer;
} MODEM_STRUCT, *MODEM_PTR;	

typedef struct _CB_STRUCT
{
	u32  P_REGPARM (*hw_read)(void *, u16, u8 *);
	u8   P_REGPARM (*hw_readb)(void *, u16, u8 *);
	void P_REGPARM (*hw_write)(void *, u16, u32);
	void P_REGPARM (*hw_writeb)(void *, u16, u8);
	void P_REGPARM (*cb_delay)(u32);
	u32  P_REGPARM (*allocate_spin_lock)(void **);
	u32  P_REGPARM (*free_spin_lock)(void *);
	u32  P_REGPARM (*acquire_spin_lock)(void *);
	u32  P_REGPARM (*release_spin_lock)(void *);
	void P_REGPARM (*adsl_rx_cells)(void *, u32, u16);
	void P_REGPARM (*adsl_tx_done)(void *);
} CB_STRUCT;	

#pragma pack(1)  // pack bytes

typedef struct _ATM_CELL
{
	u8 hdr[ATM_HEADER_SIZE];      /* ATM header */
	u8 info[ATM_PAYLOAD_SIZE];    /* ATM payload */
} ATM_CELL;

#pragma pack() // stop packing 

// firmware library prototypes

char P_REGPARM *getlibver(void);
void P_REGPARM adsl_cb_init(MODEM_PTR pmodem, CB_STRUCT *cbs);
void P_REGPARM adsl_led_on(MODEM_PTR pmodem, u16 led);
void P_REGPARM adsl_led_off(MODEM_PTR pmodem, u16 led);
void P_REGPARM adsl_led_toggle(MODEM_PTR pmodem, u16 led);
void P_REGPARM led_toggle(MODEM_PTR pmodem, u16 led);
void P_REGPARM adsl_config(MODEM_PTR pmodem, u16 modulation, u16 trellis);
u16  P_REGPARM adsl_irq_pending(MODEM_PTR pmodem);
void P_REGPARM adsl_irq_service(MODEM_PTR pmodem);
u16  P_REGPARM adsl_monitor(MODEM_PTR pmodem);
u16  P_REGPARM adsl_link_state(MODEM_PTR pmodem);
void P_REGPARM adsl_train(MODEM_PTR pmodem);
void P_REGPARM adsl_irq_disable(MODEM_PTR pmodem);
u32  P_REGPARM adsl_sizeof(void);
void P_REGPARM adsl_rxdma_init(MODEM_PTR pmodem, u32 size);
int  P_REGPARM adsl_init(MODEM_PTR pmodem);
void P_REGPARM adsl_tx(MODEM_PTR pmodem, u32 tx_start, u32 tx_end);
void P_REGPARM adsl_shutdown(MODEM_PTR pmodem);
void P_REGPARM adsl_get_mac(MODEM_PTR pmodem, u8 *macptr);
void P_REGPARM adsl_get_status(MODEM_PTR pmodem);

// callback prototypes

u32  P_REGPARM hw_read(void *pci_base, u16 Address, u8 *pData);
u8   P_REGPARM hw_readb(void *pci_base, u16 Address, u8 *pData);
void P_REGPARM hw_write(void *pci_base, u16 Address, u32 Data);
void P_REGPARM hw_writeb(void *pci_base, u16 Address, u8 Data);
void P_REGPARM cb_delay(u32 delay);
u32  P_REGPARM allocate_spin_lock(void **plock);
u32  P_REGPARM free_spin_lock(void *plock);
u32  P_REGPARM acquire_spin_lock(void *plock);
u32  P_REGPARM release_spin_lock(void *plock);
void P_REGPARM adsl_tx_done(void *user_pmodem);
void P_REGPARM adsl_rx_cells(void *user_pmodem, u32 CellPtr, u16 ncells);

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0))
void rx_bh_service(void *data);
#else
void rx_bh_service(unsigned long data);
#endif

// other prototypes
void tx_done(MODEM_PTR pmodem);
void tx_cells(MODEM_PTR pmodem);
void dump_cells(u32 cellptr, u16 size);
void show_cells(u16 tx, u32 cellptr, u16 size);
u16 count_cells(u32 cellptr, u16 size);

