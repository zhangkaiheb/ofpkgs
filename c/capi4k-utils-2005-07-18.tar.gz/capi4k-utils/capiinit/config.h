/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader 2.13.  */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* Define if you have the <capi20.h> header file.  */
#define HAVE_CAPI20_H 1

/* Define if you have the <linux/capi.h> header file.  */
#define HAVE_LINUX_CAPI_H 1

/* Name of package */
#define PACKAGE "capiinit"

/* Version number of package */
#define VERSION "1.0"

