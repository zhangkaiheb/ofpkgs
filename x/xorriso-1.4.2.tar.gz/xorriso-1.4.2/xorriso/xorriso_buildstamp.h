#ifndef Xorriso_build_timestamP
#define Xorriso_build_timestamP "-none-given-"
#endif
