#!/bin/sh
#
# $Id: makedev.sh,v 1.5 2000/02/24 13:29:26 paul Exp $
#
# This script creates all CAPI devices under /dev .
# Many/most distributions don't include these devices.

if [ "`id | grep uid=0`" = "" ]; then
	echo "In order to create device inodes, you must run this script as root."
	exit 1
fi
echo -e "Creating device inodes ... \c"

if [ $# = 1 ] ; then
	DEV=$1/dev
else
	DEV=/dev
fi

MAJ=68
MIN=0
rm -f $DEV/capi20*
mknod -m 666 $DEV/capi20 c $MAJ 0

if grep '^dialout:' /etc/group > /dev/null
then	# Debian/SuSE standard
	chgrp dialout $DEV/capi20
fi

echo "done."
