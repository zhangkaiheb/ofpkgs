#include "pulsar.h"
#include <linux/kernel.h>
#include <linux/errno.h>

void dump_truck(PDSL_MODEM pmodem)
// prints out the pmodem stucture values
{
	u32 tu32;
	u16 tu16;
	int it;

	tu32 = (u32)pmodem->pciBase;
	printk(KERN_INFO "pciBase = %x\n",tu32);
//	it = pmodem->irq;
//	printk(KERN_INFO "IRQ = %x\n",it);
//	tu16 = pmodem->modem;
//	printk(KERN_INFO "modem = %x\n",tu16);
	tu32 = (u32)pmodem->pCustData;		// User data context
	printk(KERN_INFO "pCustData = %x\n",tu32);
	tu32 = pmodem->ioimage;	// LED image register
	printk(KERN_INFO "ioimage = %x\n",tu32);
	tu16 = pmodem->tx_led_count;	// LED counters 
	printk(KERN_INFO "tx_led_count = %x\n",tu16);
	tu16 = pmodem->rx_led_count;
	printk(KERN_INFO "rx_led_count = %x\n",tu16);

	// struct PARAM_XCVR_ARRAY XcvrParam[NUM_OF_XCVR];

	// EOC_CMD 	EocCmd;		// EOC command structure

	tu32 = (u32)pmodem->pXcvrLock;
	printk(KERN_INFO "pXcvrLock = %x\n",tu32);

	tu32 = (u32)pmodem->pDslModemLock;
	printk(KERN_INFO "pDslModemLock = %x\n",tu32);

	tu32 = pmodem->RxBuffStartV;	// RX DMA Start Virtual(Linear) Address
	printk(KERN_INFO "RxBuffStartV = %x\n",tu32);
	tu32 = pmodem->RxBuffEndV;		// RX DMA End Virtual(Linear) Address
	printk(KERN_INFO "RxBuffEndV = %x\n",tu32);
	tu32 = pmodem->RxBuffStartP;	// RX DMA Start Physical Address
	printk(KERN_INFO "RxBuffStartP = %x\n",tu32);
	tu32 = pmodem->RxBuffEndP;		// RX DMA End Physical Address
	printk(KERN_INFO "RxBuffEndP = %x\n",tu32);

	tu16 = pmodem->RxCellCount;	// 0-255
	printk(KERN_INFO "rx_led_count = %x\n",tu16);
	tu16 = pmodem->RetrainEnable;
	printk(KERN_INFO "rx_led_count = %x\n",tu16);
	tu32 = pmodem->GpMonitorInterval;  // milli-sec
	printk(KERN_INFO "GpMonitorInterval = %x\n",tu32);

	//void		(*ReceiveCells)(PDSL_MODEM, u32, u16);
	//void		(*Delay)(u32);
	//void		(*XmitDmaDone)(PDSL_MODEM);
	//u32		(*AllocateSpinLock)(void **);
	//u32		(*FreeSpinLock)(void *);
	//u32		(*AcquireSpinLock)(void *);
	//u32		(*ReleaseSpinLock)(void *);
	//u32		(*ReadPciReg)(PDSL_MODEM, u16, u8 *);
	//u8		(*ReadPciRegB)(PDSL_MODEM,u16, u8 *);
	//void		(*WritePciReg)(PDSL_MODEM,u16, u32);
	//void		(*WritePciRegB)(PDSL_MODEM, u16, u8);

	tu32 = pmodem->DownstreamRate;
	printk(KERN_INFO "DownstreamRate = %x\n",tu32);
	tu32 = pmodem->UpstreamRate;
	printk(KERN_INFO "UpstreamRate = %x\n",tu32);
	tu16 = pmodem->DslLinkState;
	printk(KERN_INFO " = %x\n",tu16);
	tu32 = pmodem->TotalNumTxCells;		// Running count of transmitted cells
	printk(KERN_INFO "TotalNumTxCells = %x\n",tu32);
	tu32 = pmodem->TotalNumRxCells;		// Running count of received cells
	printk(KERN_INFO "TotalNumRxCells = %x\n",tu32);
	tu32 = pmodem->RetrainCount;			// Running count of retrains initiated
	printk(KERN_INFO "RetrainCount = %x\n",tu32);
	tu32 = pmodem->RxDmaErrCnt;			// Count of number of receive DMA errors detected
	printk(KERN_INFO "RxDMAErrCnt = %x\n",tu32);
	tu16 = pmodem->HardwareStatus;			// GP_SUCCESS if hardware is ok, otherwise GP_FAIL.
	printk(KERN_INFO "HardwareStatus = %x\n",tu16);
	//tu16 = StatusBuffer[512];		// GpStatusXcvr(): Status buffer containing XCVR status
	tu16 = pmodem->TestIODriverResult;		// Stored return status from Gti_TestIODrivers, which is called by
	printk(KERN_INFO "TestIODriverResult = %x\n",tu16);
											// GpCheckHardware

	//u16		Counters[COUNTERS_LEN/sizeof(u16)];   // Counters array read from transceiver status cmd.
	//u16		AccCounters[COUNTERS_LEN/sizeof(u16)];// Counters array read from transceiver and accumulated
	//u16		Failures[FAILURES_LEN/sizeof(u16)];   // Failures array read from transceiver status cmd.

	tu32 = pmodem->TrainingTimer;			// Training timeout timer
	printk(KERN_INFO "TrainingTimer = %x\n",tu32);
	tu32 = pmodem->PendingCellDelTimer;	// Pending cell delineation timeout timer
	printk(KERN_INFO "PendingCellTimer = %x\n",tu32);

	tu32 = pmodem->TxDmaTimer;				// Used to timeout the transmit DMA operation.
	printk(KERN_INFO "TxDmaTimer = %x\n",tu32);
	tu16 = pmodem->TxDmaPending;			// Set when a Tx DMA operation is initiated.
	printk(KERN_INFO "TxDmaPending = %x\n",tu16);
											// Cleared when the Tx DMA complete interrupt occurs.
	tu16 = pmodem->InterruptStatus;		// Interrupt status word - read from hardware
	printk(KERN_INFO " = %x\n",tu16);
	tu16 = pmodem->InitStatus;				// Initialization status - indicates how far initialization or shutdown
	printk(KERN_INFO "InitStatus = %x\n",tu16);
										// has progressed.

	tu32 = pmodem->RxCellRdPtrSav;			// Saves the last value of the read buffer pointer
	printk(KERN_INFO "RxCellRdPtrSav = %x\n",tu32);

	tu16 = pmodem->SNRStatusRead;		// 0 = SNR margin status has not yet been read since the last startup or retrain.
	printk(KERN_INFO "SNRStatusRead = %x\n",tu16);

	tu16 = pmodem->LocalDspAddH;		// Local image of DSP address pointer high byte. Used for reading from local array.
	printk(KERN_INFO "LocalDspAddL = %x\n",tu16);
	tu16 = pmodem->LocalDspAddL;		// Local image of DSP address pointer low byte.
	printk(KERN_INFO "LocalDspAddL = %x\n",tu16);

	tu16 = pmodem->DspAddH;			// DSP address pointer high byte. Used for reading from DSP and storing in local array.
	printk(KERN_INFO "DspAddH = %x\n",tu16);
	tu16 = pmodem->DspAddL;			// DSP address pointer low byte.
	printk(KERN_INFO "DspAddL = %x\n",tu16);

	// The following are local copies of data required to compute SNR margin

	//u16		DspRamD6_H[256];	// Local image of DSP RAM block 0xD6 high byte (SQ per bin data)
	//u16		DspRamD6_L[256];	// Local image of DSP RAM block 0xD6 low byte

	//u16		DspRamD7_H[256];	// Local image of DSP RAM block 0xD7 high byte  (DS bit loading data)
	//u16		DspRamD7_L[256];	// Local image of DSP RAM block 0xD7 low byte
	//u16		DspRamD7_E[256];	// Local image of DSP RAM block 0xD7 extended byte

	//u16		DspRamF4_H[256];	// Local image of DSP RAM block 0xF4 high byte   (US bit loading data)
	//u16		DspRamF4_L[256];	// Local image of DSP RAM block 0xF4 low byte
	//u16		DspRamF4_E[256];	// Local image of DSP RAM block 0xF4 extended byte

	// Variables used by retrain algorithm
	tu16 = pmodem->MaxCrcErrorsPerSecThreshold;
	printk(KERN_INFO "MaxCrcErrorsPerSec = %x\n",tu16);
	tu16 = pmodem->DownstreamRateToMaxCrcErrorsPerMinDivider;
	printk(KERN_INFO "DownstramDivider = %x\n",tu16);
	tu16 = pmodem->CrcErrorsPerMinThreshold;
	printk(KERN_INFO "MaxCrcErrorsPerMin = %x\n",tu16);
	tu16 = pmodem->CrcErrorsPerMin;
	printk(KERN_INFO "CrcErrorsPerMin = %x\n",tu16);
	tu16 = pmodem->ExcessiveConsecutiveCrcErrorsPerTickCount;
	printk(KERN_INFO "ExcConCRCErrPerTicCnt = %x\n",tu16);
	tu16 = pmodem->ExcessiveConsecutiveCrcErrorsPerMinCount;
	printk(KERN_INFO "ExcConCRCErrPerMinCnt = %x\n",tu16);
	tu16 = pmodem->TickCounter;
	printk(KERN_INFO "TickCounter = %x\n",tu16);
}	
	
