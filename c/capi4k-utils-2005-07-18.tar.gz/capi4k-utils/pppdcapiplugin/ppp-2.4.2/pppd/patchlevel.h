/* $Id: patchlevel.h,v 1.1 2004/02/14 15:02:48 keil Exp $ */

#define VERSION		"2.4.2"
#define DATE		"13 Jan 2004"
