/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader 2.13.  */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

#define VERSION "1.0"
#define PACKAGE "capiinfo"
/* #undef CONFIG_SBINDIR */
/* #undef CONFIG_MANDIR */

/* Define if you have the <linux/capi.h> header file.  */
#define HAVE_LINUX_CAPI_H 1

/* Name of package */
#define PACKAGE "capiinfo"

/* Version number of package */
#define VERSION "1.0"

